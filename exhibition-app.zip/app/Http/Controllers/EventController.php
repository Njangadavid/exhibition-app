<?php

namespace App\Http\Controllers;

use Illuminate\Validation\ValidationException;

use Illuminate\Http\Request;
use App\Models\Event;
use App\Models\FloorplanDesign;
use App\Models\FloorplanItem;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;

class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Get events visible to the current user
        $events = Event::visibleTo(auth()->user())->latest()->paginate(10);
        
        return view('events.index', compact('events'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Check if user has permission to create events
        if (!auth()->user()->hasPermission('create_events')) {
            abort(403, 'You do not have permission to create events.');
        }

        $statusOptions = Event::getStatusOptions();
        $users = \App\Models\User::active()->get();
        
        return view('events.create', compact('statusOptions', 'users'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Check if user has permission to create events
        if (!auth()->user()->hasPermission('create_events')) {
            abort(403, 'You do not have permission to create events.');
        }

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'status' => 'required|in:' . implode(',', array_keys(Event::getStatusOptions())),
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'assigned_users' => 'nullable|array',
            'assigned_users.*' => 'exists:users,id',
        ]);

        // Generate slug from name
        $validated['slug'] = Event::generateSlug($validated['name']);

        // Handle logo upload
        if ($request->hasFile('logo')) {
            $logoPath = $request->file('logo')->store('events/logos', 'public');
            $validated['logo'] = $logoPath;
        }

        // Create the event with owner
        $validated['owner_id'] = auth()->id();
        $event = Event::create($validated);

        // Assign users to the event (always include the owner)
        $assignedUsers = $request->input('assigned_users', []);
        $assignedUsers[] = auth()->id(); // Always include the owner
        $assignedUsers = array_unique($assignedUsers); // Remove duplicates
        $event->users()->sync($assignedUsers);

        return redirect()->route('events.index')
            ->with('success', 'Event created successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Event $event)
    {
        // Check if user can view this event
        if (!$event->canBeViewedBy(auth()->user())) {
            abort(403, 'You do not have permission to view this event.');
        }

        return view('events.show', compact('event'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Event $event)
    {
        // Check if user can view this event
        if (!$event->canBeViewedBy(auth()->user())) {
            abort(403, 'You do not have permission to edit this event.');
        }

        $statusOptions = Event::getStatusOptions();
        $users = \App\Models\User::active()->get();
        
        return view('events.edit', compact('event', 'statusOptions', 'users'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Event $event)
    {
        // Check if user can view this event
        if (!$event->canBeViewedBy(auth()->user())) {
            abort(403, 'You do not have permission to edit this event.');
        }


        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'status' => 'required|in:' . implode(',', array_keys(Event::getStatusOptions())),
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'assigned_users' => 'nullable|array',
            'assigned_users.*' => 'exists:users,id',
        ]);

        // Generate slug from name (only if name changed)
        if ($event->name !== $validated['name']) {
            $validated['slug'] = Event::generateSlug($validated['name']);
        }

        // Handle logo upload
        if ($request->hasFile('logo')) {
            // Delete old logo if exists
            if ($event->logo) {
                Storage::disk('public')->delete($event->logo);
            }
            
            $logoPath = $request->file('logo')->store('events/logos', 'public');
            $validated['logo'] = $logoPath;
        }

        $event->update($validated);

        // Update user assignments
        $assignedUsers = $request->input('assigned_users', []);
        
        // Ensure it's an array
        if (!is_array($assignedUsers)) {
            $assignedUsers = [];
        }
        
        // If current user is admin, they can manage ownership
        if (auth()->user()->hasRole('admin')) {
            // Admin can remove owner from assignments if they want
            $event->users()->sync($assignedUsers);
        } else {
            // Non-admin users: always include the owner
            $assignedUsers[] = $event->owner_id; // Always include the owner
            $assignedUsers = array_unique($assignedUsers); // Remove duplicates
            $event->users()->sync($assignedUsers);
        }

        return redirect()->route('events.index')
            ->with('success', 'Event updated successfully!');
    }

    /**
     * Transfer event ownership (admin only)
     */
    public function transferOwnership(Request $request, Event $event)
    {
        // Check if user is admin
        if (!auth()->user()->hasRole('admin')) {
            abort(403, 'Only administrators can transfer event ownership.');
        }

        $validated = $request->validate([
            'new_owner_id' => 'required|exists:users,id',
        ]);

        $newOwner = \App\Models\User::findOrFail($validated['new_owner_id']);

        if ($event->transferOwnership($newOwner, auth()->user())) {
            return redirect()->back()
                ->with('success', "Event ownership transferred to {$newOwner->name} successfully!");
        } else {
            return redirect()->back()
                ->with('error', 'Failed to transfer event ownership.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Event $event)
    {
        try {
            // Delete logo if exists
            if ($event->logo) {
                Storage::disk('public')->delete($event->logo);
            }

            $event->delete();

            // Always return JSON for this route since it's designed for AJAX
            return response()->json([
                'success' => true,
                'message' => 'Event deleted successfully!'
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to delete event', [
                'event_id' => $event->id,
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to delete event. Please try again.'
            ], 500);
        }
    }

    /**
     * Public event display (no authentication required).
     */
    public function publicShow(Event $event)
    {
        // Check if event is published or active
        if (!in_array($event->status, ['published', 'active'])) {
            abort(404, 'Event not found.');
        }

        return view('events.public.show', compact('event'));
    }







    /**
     * Dashboard view for events.
     */
    public function dashboard()
    {
        $user = auth()->user();
        
        // Get events visible to the current user
        $visibleEvents = Event::visibleTo($user);
        
        $activeEvents = $visibleEvents->active()->count();
        $upcomingEvents = $visibleEvents->upcoming()->count();
        $completedEvents = $visibleEvents->completed()->count();
        $totalEvents = $visibleEvents->count();
        
        $recentEvents = $visibleEvents->latest()->take(5)->get();
        $upcomingEventsList = $visibleEvents->upcoming()->take(3)->get();
        return view('events.dashboard', compact(
            'activeEvents',
            'upcomingEvents', 
            'completedEvents',
            'totalEvents',
            'recentEvents',
            'upcomingEventsList'
        ));
    }

    /**
     * Event-specific dashboard.
     */
    public function eventDashboard(Event $event)
    {
        // Check if user has permission to view events
        if (!auth()->user()->hasPermission('view_events')) {
            abort(403, 'You do not have permission to view events.');
        }

        // Check if user can view this specific event
        if (!$event->canBeViewedBy(auth()->user())) {
            abort(403, 'You do not have permission to view this event.');
        }

        return view('events.dashboard', compact('event'));
    }

    /**
     * Event floorplan.
     */
    public function floorplan(Event $event)
    {
        // Check if user has permission to manage floorplans
        if (!auth()->user()->hasPermission('manage_floorplans') && !auth()->user()->hasPermission('manage_own_floorplans')) {
            abort(403, 'You do not have permission to manage floorplans.');
        }

        // Load existing floorplan design if exists
        $floorplanDesign = $event->floorplanDesign()->with('items')->first();
        
        return view('events.floorplan', compact('event', 'floorplanDesign'));
    }

    /**
     * Event registration form.
     */
    public function registration(Event $event)
    {
        return view('events.registration', compact('event'));
    }

    /**
     * Save floorplan design and items.
     */
    public function saveFloorplan(Request $request, Event $event)
    {
        try {
            // Log the incoming request data
            \Illuminate\Support\Facades\Log::info('Floorplan save request received', [
                'event_id' => $event->id,
                'request_data' => $request->all(),
                'items_count' => count($request->input('items', [])),
                'sample_item' => $request->input('items.0', 'No items')
            ]);
            
            $validated = $request->validate([
            // Floorplan design properties
            'name' => 'string|max:255',
            'canvas_size' => 'string',
            'canvas_width' => 'integer',
            'canvas_height' => 'integer',
            'bg_color' => 'string',
            'fill_color' => 'string',
            'stroke_color' => 'string',
            'text_color' => 'string',
            'border_width' => 'integer',
            'font_family' => 'string',
            'font_size' => 'integer',
            'grid_size' => 'integer',
            'grid_color' => 'string',
            'show_grid' => 'boolean',
            'snap_to_grid' => 'boolean',
            'default_booth_capacity' => 'integer',
            'label_prefix' => 'string|max:3',
            'starting_label_number' => 'integer',
            'default_label_position' => 'string|in:top,bottom,left,right,center',
            'default_price' => 'numeric',
            'enable_auto_labeling' => 'boolean',
            'default_booth_width_meters' => 'numeric|min:0.1|max:100',
            'default_booth_height_meters' => 'numeric|min:0.1|max:100',
            'default_label_font_size' => 'integer|min:8|max:72',
            'default_label_background_color' => 'string|regex:/^#[0-9A-F]{6}$/i',
            'default_label_color' => 'string|regex:/^#[0-9A-F]{6}$/i',

            
            // Items array
            'items' => 'array',
            'items.*.item_id' => 'required|string',
            'items.*.type' => 'required|string',
            'items.*.x' => 'required|numeric',
            'items.*.y' => 'required|numeric',
            'items.*.width' => 'nullable|numeric',
            'items.*.height' => 'nullable|numeric',
            'items.*.radius' => 'nullable|numeric',
            'items.*.size' => 'nullable|numeric',
            'items.*.rotation' => 'nullable|numeric',
            'items.*.fill_color' => 'nullable|string',
            'items.*.stroke_color' => 'nullable|string',
            'items.*.border_width' => 'nullable|integer',
            'items.*.font_family' => 'nullable|string',
            'items.*.font_size' => 'nullable|integer',
            'items.*.text_color' => 'nullable|string',
            'items.*.bookable' => 'boolean',
            'items.*.max_capacity' => 'nullable|integer',
            'items.*.label' => 'nullable|string',
            'items.*.item_name' => 'nullable|string',
            'items.*.price' => 'nullable|numeric',
            'items.*.label_position' => 'nullable|string|in:top,bottom,left,right,center',
            'items.*.text_content' => 'nullable|string',
            'items.*.label_font_size' => 'nullable|integer|min:8|max:72',
            'items.*.label_background_color' => 'nullable|string|regex:/^#[0-9A-F]{6}$/i',
            'items.*.label_color' => 'nullable|string|regex:/^#[0-9A-F]{6}$/i',
            'items.*.booth_width_meters' => 'nullable|numeric|min:0.1|max:100',
            'items.*.booth_height_meters' => 'nullable|numeric|min:0.1|max:100',
        ]);
        
        } catch (ValidationException $e) {
            \Illuminate\Support\Facades\Log::warning('Floorplan validation failed', [
                'event_id' => $event->id,
                'errors' => $e->errors(),
                'request_data' => $request->all()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Floorplan validation failed',
                'errors' => $e->errors()
            ], 422);
        }

        try {
            DB::beginTransaction();
            \Illuminate\Support\Facades\Log::info('Database transaction started for floorplan save');

            // Create or update floorplan design
            $floorplanDesign = $event->floorplanDesign()->updateOrCreate(
                ['event_id' => $event->id],
                array_filter($validated, function($key) {
                    return $key !== 'items';
                }, ARRAY_FILTER_USE_KEY)
            );

            \Illuminate\Support\Facades\Log::info('Floorplan design created/updated', [
                'floorplan_id' => $floorplanDesign->id,
                'event_id' => $event->id
            ]);

            if (isset($validated['items'])) {
                // Get existing items to preserve IDs
                $existingItems = $floorplanDesign->items()->get()->keyBy('item_id');
                $newItemIds = collect($validated['items'])->pluck('item_id')->toArray();
                
                \Illuminate\Support\Facades\Log::info('Processing floorplan items', [
                    'existing_count' => $existingItems->count(),
                    'new_count' => count($validated['items'])
                ]);
                
                // Delete items that are no longer in the floorplan
                $itemsToDelete = $existingItems->keys()->diff($newItemIds)->values();
                \Illuminate\Support\Facades\Log::info('Delete analysis', [
                    'items_to_delete_count' => $itemsToDelete->count()
                ]);
                
                if ($itemsToDelete->count() > 0) {
                    \Illuminate\Support\Facades\Log::info('Items to be deleted', [
                        'count' => $itemsToDelete->count()
                    ]);
                    
                    // Note: Individual booking checks are now handled in the deletion loop below
                    
                    // Delete items one by one for better reliability
                    $deletedCount = 0;
                    foreach ($itemsToDelete as $itemId) {
                        $item = $floorplanDesign->items()->where('item_id', $itemId)->first();
                        if ($item) {
                            // Delete the item
                            $deleted = $item->delete();
                            if ($deleted) {
                                $deletedCount++;
                            }
                        } else {
                            // Try alternative lookups in case of data type issues
                            $itemAsString = (string) $itemId;
                            $itemAsInt = (int) $itemId;
                            
                            $itemString = $floorplanDesign->items()->where('item_id', $itemAsString)->first();
                            $itemInt = $floorplanDesign->items()->where('item_id', $itemAsInt)->first();
                            
                            if ($itemString) {
                                $deleted = $itemString->delete();
                                if ($deleted) {
                                    $deletedCount++;
                                }
                            } elseif ($itemInt) {
                                $deleted = $itemInt->delete();
                                if ($deleted) {
                                    $deletedCount++;
                                }
                            }
                        }
                    }
                    
                    \Illuminate\Support\Facades\Log::info('Deletion completed', [
                        'deleted_count' => $deletedCount
                    ]);
                } else {
                    \Illuminate\Support\Facades\Log::info('No items to delete');
                }
                
                // Update or create items
                foreach ($validated['items'] as $index => $itemData) {
                    
                    $itemData['floorplan_design_id'] = $floorplanDesign->id;
                    
                    if ($existingItems->has($itemData['item_id'])) {
                        // Update existing item to preserve ID and relationships
                        $existingItem = $existingItems->get($itemData['item_id']);
                        $existingItem->update($itemData);
                    } else {
                        // Create new item
                        FloorplanItem::create($itemData);
                    }
                }
                
                \Illuminate\Support\Facades\Log::info('Floorplan items processed successfully');
            }

            DB::commit();
            \Illuminate\Support\Facades\Log::info('Floorplan saved successfully', [
                'floorplan_id' => $floorplanDesign->id,
                'total_items' => isset($validated['items']) ? count($validated['items']) : 0
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Floorplan saved successfully!',
                'floorplan_id' => $floorplanDesign->id
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            
            \Illuminate\Support\Facades\Log::error('Error saving floorplan', [
                'event_id' => $event->id,
                'error' => $e->getMessage(),
                'error_class' => get_class($e),
                'trace' => $e->getTraceAsString(),
                'request_data' => $request->all()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Error saving floorplan: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Load floorplan design and items.
     */
    public function loadFloorplan(Event $event)
    {
        $floorplanDesign = $event->floorplanDesign()->with('items')->first();

        if (!$floorplanDesign) {
            return response()->json([
                'success' => false,
                'message' => 'No floorplan found for this event'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'floorplan' => $floorplanDesign->toArray()
        ]);
    }

    /**
     * Check for orphaned bookings (bookings that reference non-existent floorplan items)
     */
    public function checkOrphanedBookings(Event $event)
    {
        try {
            // First, let's check if the event has any bookings at all
            $totalBookings = $event->bookings()->count();
            
            // Get all bookings for this event
            $allBookings = $event->bookings()->get();
            
            // Check which bookings have valid floorplan items
            $orphanedBookings = collect();
            
            foreach ($allBookings as $booking) {
                // Check if the floorplan item exists
                $floorplanItem = \App\Models\FloorplanItem::find($booking->floorplan_item_id);
                if (!$floorplanItem) {
                    $orphanedBookings->push($booking);
                }
            }
            
            return response()->json([
                'success' => true,
                'orphaned_bookings' => $orphanedBookings->map(function($booking) {
                    return [
                        'id' => $booking->id,
                        'booking_reference' => $booking->booking_reference,
                        'status' => $booking->status,
                        'owner_name' => $booking->owner_details['name'] ?? 'Unknown',
                        'owner_email' => $booking->owner_details['email'] ?? 'Unknown',
                        'created_at' => $booking->created_at->format('Y-m-d H:i:s'),
                        'floorplan_item_id' => $booking->floorplan_item_id,
                    ];
                }),
                'count' => $orphanedBookings->count(),
                'total_bookings' => $totalBookings,
                'debug_info' => [
                    'event_id' => $event->id,
                    'event_name' => $event->name,
                    'method' => 'manual_check'
                ]
            ]);
            
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Error checking orphaned bookings', [
                'event_id' => $event->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Error checking orphaned bookings: ' . $e->getMessage(),
                'debug_info' => [
                    'event_id' => $event->id,
                    'error_file' => $e->getFile(),
                    'error_line' => $e->getLine()
                ]
            ], 500);
        }
    }

    /**
     * Clean up orphaned bookings (remove bookings that reference non-existent floorplan items)
     */
    public function cleanupOrphanedBookings(Event $event)
    {
        try {
            DB::beginTransaction();

            // Get all bookings for this event
            $allBookings = $event->bookings()->get();
            
            // Check which bookings have valid floorplan items
            $orphanedBookings = collect();
            
            foreach ($allBookings as $booking) {
                // Check if the floorplan item exists
                $floorplanItem = \App\Models\FloorplanItem::find($booking->floorplan_item_id);
                if (!$floorplanItem) {
                    $orphanedBookings->push($booking);
                }
            }

            $count = $orphanedBookings->count();
            
            if ($count > 0) {
                $orphanedBookings->each(function($booking) {
                    // Log the cleanup for audit purposes
                    \Illuminate\Support\Facades\Log::warning('Cleaning up orphaned booking', [
                        'booking_id' => $booking->id,
                        'booking_reference' => $booking->booking_reference,
                        'event_id' => $booking->event_id,
                        'floorplan_item_id' => $booking->floorplan_item_id,
                        'owner_email' => $booking->owner_details['email'] ?? 'Unknown'
                    ]);
                    
                    $booking->delete();
                });
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => "Cleaned up {$count} orphaned bookings",
                'cleaned_count' => $count,
                'total_bookings_checked' => $allBookings->count()
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            
            \Illuminate\Support\Facades\Log::error('Error cleaning up orphaned bookings', [
                'event_id' => $event->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Error cleaning up orphaned bookings: ' . $e->getMessage(),
                'debug_info' => [
                    'event_id' => $event->id,
                    'error_file' => $e->getFile(),
                    'error_line' => $e->getLine()
                ]
            ], 500);
        }
    }

    /**
     * Display bookings report for the event
     */
    public function bookingsReport(Event $event)
    {
        // Get all booth owners with their bookings for this event
        $boothOwners = \App\Models\BoothOwner::whereHas('booking', function($query) use ($event) {
            $query->where('event_id', $event->id);
        })->with(['booking.floorplanItem.floorplanDesign', 'booking.payments', 'boothMembers'])
        ->get();

        // Get statistics
        $stats = [
            'total_booth_owners' => $boothOwners->count(),
            'total_bookings' => $boothOwners->count(), // Since each booth owner has one booking
            'paid_bookings' => $boothOwners->filter(function($boothOwner) {
                return $boothOwner->booking && $boothOwner->booking->payments->where('status', 'completed')->count() > 0;
            })->count(),
            'pending_payments' => $boothOwners->filter(function($boothOwner) {
                return $boothOwner->booking && $boothOwner->booking->payments->where('status', 'pending')->count() > 0;
            })->count(),
            'total_revenue' => $boothOwners->sum(function($boothOwner) {
                if ($boothOwner->booking && $boothOwner->booking->payments->where('status', 'completed')->count() > 0) {
                    return $boothOwner->booking->floorplanItem ? $boothOwner->booking->floorplanItem->price : 0;
                }
                return 0;
            }),
            'paid_revenue' => $boothOwners->sum(function($boothOwner) {
                if ($boothOwner->booking && $boothOwner->booking->payments->where('status', 'completed')->count() > 0) {
                    return $boothOwner->booking->floorplanItem ? $boothOwner->booking->floorplanItem->price : 0;
                }
                return 0;
            }),
            'total_potential_revenue' => $boothOwners->sum(function($boothOwner) {
                return $boothOwner->booking && $boothOwner->booking->floorplanItem ? $boothOwner->booking->floorplanItem->price : 0;
            })
        ];

        return view('events.reports.bookings', compact('event', 'boothOwners', 'stats'));
    }

    /**
     * Export bookings report as PDF
     */
    public function bookingsReportPdf(Event $event)
    {
        // Get all booth owners with their bookings for this event
        $boothOwners = \App\Models\BoothOwner::whereHas('booking', function($query) use ($event) {
            $query->where('event_id', $event->id);
        })->with(['booking.floorplanItem.floorplanDesign', 'booking.payments', 'boothMembers'])
        ->get();

        // Get statistics
        $stats = [
            'total_booth_owners' => $boothOwners->count(),
            'total_bookings' => $boothOwners->count(),
            'paid_bookings' => $boothOwners->filter(function($boothOwner) {
                return $boothOwner->booking && $boothOwner->booking->payments->where('status', 'completed')->count() > 0;
            })->count(),
            'pending_payments' => $boothOwners->filter(function($boothOwner) {
                return $boothOwner->booking && $boothOwner->booking->payments->where('status', 'pending')->count() > 0;
            })->count(),
            'total_revenue' => $boothOwners->sum(function($boothOwner) {
                if ($boothOwner->booking && $boothOwner->booking->payments->where('status', 'completed')->count() > 0) {
                    return $boothOwner->booking->floorplanItem ? $boothOwner->booking->floorplanItem->price : 0;
                }
                return 0;
            }),
            'total_potential_revenue' => $boothOwners->sum(function($boothOwner) {
                return $boothOwner->booking && $boothOwner->booking->floorplanItem ? $boothOwner->booking->floorplanItem->price : 0;
            }),
            'total_booth_members' => $boothOwners->sum(function($boothOwner) { 
                return $boothOwner->boothMembers->count(); 
            }),
            'fully_occupied' => $boothOwners->filter(function($boothOwner) { 
                $floorplanItem = $boothOwner->booking->floorplanItem ?? null;
                return $floorplanItem && $boothOwner->boothMembers->count() >= ($floorplanItem->max_capacity ?? 5);
            })->count(),
            'partially_filled' => $boothOwners->filter(function($boothOwner) { 
                $floorplanItem = $boothOwner->booking->floorplanItem ?? null;
                return $floorplanItem && $boothOwner->boothMembers->count() > 0 && $boothOwner->boothMembers->count() < ($floorplanItem->max_capacity ?? 5);
            })->count()
        ];

        $pdf = Pdf::loadView('events.reports.bookings-pdf', compact('event', 'boothOwners', 'stats'));
        
        return $pdf->download('exhibitor-bookings-report-' . $event->slug . '-' . date('Y-m-d') . '.pdf');
    }

    /**
     * Display detailed view of a specific booth owner
     */
    public function boothOwnerDetails(Event $event, \App\Models\BoothOwner $boothOwner)
    {
        // Verify the booth owner belongs to this event
        if ($boothOwner->booking->event_id != $event->id) {
            dd('Booth owner not found for this event');
        }

        // Load all relationships
        $boothOwner->load([
            'booking.floorplanItem.floorplanDesign',
            'booking.payments',
            'boothMembers'
        ]);
        $formBuilder = $event->formBuilders()->where('type', 'member_registration')->first();
        // Get the member form fields to map field_id to field_purpose
       $formFields = $formBuilder->fields()->where('type', '!=', 'section')->get();
        $memberFormFields = \App\Models\FormField::where('form_builder_id', $boothOwner->booking->event->member_form_id ?? null)
            ->get()
            ->keyBy('field_id');
//Booth members
$boothMembers = $boothOwner->boothMembers;
        // Get payment statistics
        $payments = $boothOwner->booking->payments;
        $totalPaid = $payments->where('status', 'completed')->sum('amount');
        $pendingAmount = $payments->where('status', 'pending')->sum('amount');
        $paymentStatus = $payments->where('status', 'completed')->count() > 0 ? 'paid' : 
                        ($payments->where('status', 'pending')->count() > 0 ? 'pending' : 'unpaid');

        return view('events.reports.booth-owner-details', compact(
            'event', 
            'boothOwner', 
            'totalPaid', 
            'pendingAmount', 
            'paymentStatus',
            'payments',
            'memberFormFields',
            'formFields',
            'boothMembers'
        ));
    }

    /**
     * Get form fields for adding a new booth member
     */
    public function getFormFieldsForNewMember(\App\Models\BoothOwner $boothOwner)
    {
        try {
            // Load the booth owner with event relationship
            $boothOwner->load('booking.event');
            
            // Get the member form fields (including sections for proper layout)
            $formBuilder = $boothOwner->booking->event->formBuilders()->where('type', 'member_registration')->first();
            $formFields = $formBuilder ? $formBuilder->fields()->orderBy('sort_order')->get() : collect();
            
            return response()->json([
                'success' => true,
                'formFields' => $formFields
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error loading form fields: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a new booth member
     */
    public function storeBoothMember(Request $request)
    {
        try {
            $request->validate([
                'booth_owner_id' => 'required|exists:booth_owners,id',
                'form_responses' => 'required|array'
            ]);

            // Check if booth has capacity
            $boothOwner = \App\Models\BoothOwner::with('booking.floorplanItem')->findOrFail($request->booth_owner_id);
            $currentMemberCount = $boothOwner->boothMembers()->count();
            $maxCapacity = $boothOwner->booking->floorplanItem->max_capacity ?? 2;

            if ($currentMemberCount >= $maxCapacity) {
                return response()->json([
                    'success' => false,
                    'message' => 'Booth has reached maximum capacity'
                ], 400);
            }

            // Create the new booth member
            $boothMember = \App\Models\BoothMember::create([
                'booth_owner_id' => $request->booth_owner_id,
                'qr_code' => \App\Models\BoothMember::generateQrCode(),
                'form_responses' => $request->input('form_responses'),
                'status' => 'active'
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Member added successfully',
                'member' => $boothMember
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error adding member: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get booth member data for editing
     */
    public function getBoothMemberForEdit(\App\Models\BoothMember $member)
    {
        try {
            // Load the member with form responses
            $member->load('boothOwner.booking.event');
            
            // Get the member form fields (including sections for proper layout)
            $formBuilder = $member->boothOwner->booking->event->formBuilders()->where('type', 'member_registration')->first();
            $formFields = $formBuilder ? $formBuilder->fields()->orderBy('sort_order')->get() : collect();
            
            return response()->json([
                'success' => true,
                'member' => $member,
                'formFields' => $formFields
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error loading member data: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update booth member
     */
    public function updateBoothMember(\App\Http\Requests\UpdateBoothMemberRequest $request, \App\Models\BoothMember $member)
    {
        try {
            $member->update([
                'form_responses' => $request->input('form_responses')
            ]);
            
            return response()->json([
                'success' => true,
                'message' => 'Member updated successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error updating member: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete booth member
     */
    public function deleteBoothMember(\App\Models\BoothMember $member)
    {
        try {
            $member->delete();
            
            return response()->json([
                'success' => true,
                'message' => 'Member deleted successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting member: ' . $e->getMessage()
            ], 500);
        }
    }
}
