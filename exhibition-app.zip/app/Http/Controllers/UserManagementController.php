<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserManagementController extends Controller
{
    /**
     * Display a listing of users.
     */
    public function index(Request $request)
    {
        // Check if user has permission to manage users
        if (!auth()->user()->hasPermission('manage_users')) {
            abort(403, 'You do not have permission to manage users.');
        }

        $query = User::with('roles');

        // Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        // Filter by role
        if ($request->filled('role')) {
            $query->whereHas('roles', function ($q) use ($request) {
                $q->where('name', $request->role);
            });
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('is_active', $request->status === 'active');
        }

        $users = $query->paginate(15);
        $roles = Role::active()->get();

        return view('admin.users.index', compact('users', 'roles'));
    }

    /**
     * Show the form for creating a new user.
     */
    public function create()
    {
        // Check if user has permission to manage users
        if (!auth()->user()->hasPermission('manage_users')) {
            abort(403, 'You do not have permission to manage users.');
        }

        $roles = Role::active()->get();
        return view('admin.users.create', compact('roles'));
    }

    /**
     * Store a newly created user.
     */
    public function store(Request $request)
    {
        // Check if user has permission to manage users
        if (!auth()->user()->hasPermission('manage_users')) {
            abort(403, 'You do not have permission to manage users.');
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'roles' => 'array',
            'roles.*' => 'exists:roles,id',
            'is_active' => 'boolean',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'is_active' => $request->has('is_active'),
        ]);

        // Assign roles
        if ($request->filled('roles')) {
            $roles = Role::whereIn('id', $request->roles)->get();
            foreach ($roles as $role) {
                $user->assignRole($role, auth()->user());
            }
        }

        return redirect()->route('admin.users.index')
                        ->with('success', 'User created successfully.');
    }

    /**
     * Display the specified user.
     */
    public function show(User $user)
    {
        // Check if user has permission to manage users
        if (!auth()->user()->hasPermission('manage_users')) {
            abort(403, 'You do not have permission to manage users.');
        }

        $user->load('roles.permissions');
        return view('admin.users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified user.
     */
    public function edit(User $user)
    {
        // Check if user has permission to manage users
        if (!auth()->user()->hasPermission('manage_users')) {
            abort(403, 'You do not have permission to manage users.');
        }

        $roles = Role::active()->get();
        $user->load('roles');
        return view('admin.users.edit', compact('user', 'roles'));
    }

    /**
     * Update the specified user.
     */
    public function update(Request $request, User $user)
    {
        // Check if user has permission to manage users
        if (!auth()->user()->hasPermission('manage_users')) {
            abort(403, 'You do not have permission to manage users.');
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique('users')->ignore($user->id),
            ],
            'password' => 'nullable|string|min:8|confirmed',
            'roles' => 'array',
            'roles.*' => 'exists:roles,id',
            'is_active' => 'boolean',
        ]);

        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'is_active' => $request->has('is_active'),
        ]);

        // Update password if provided
        if ($request->filled('password')) {
            $user->update([
                'password' => Hash::make($request->password),
            ]);
        }

        // Update roles
        if ($request->has('roles')) {
            $user->roles()->sync($request->roles);
        }

        return redirect()->route('admin.users.index')
                        ->with('success', 'User updated successfully.');
    }

    /**
     * Remove the specified user.
     */
    public function destroy(User $user)
    {
        // Check if user has permission to manage users
        if (!auth()->user()->hasPermission('manage_users')) {
            abort(403, 'You do not have permission to manage users.');
        }

        // Prevent deleting the current user
        if ($user->id === auth()->id()) {
            return redirect()->route('admin.users.index')
                            ->with('error', 'You cannot delete your own account.');
        }

        $user->delete();

        return redirect()->route('admin.users.index')
                        ->with('success', 'User deleted successfully.');
    }

    /**
     * Toggle user active status.
     */
    public function toggleStatus(User $user)
    {
        // Check if user has permission to manage users
        if (!auth()->user()->hasPermission('manage_users')) {
            abort(403, 'You do not have permission to manage users.');
        }

        // Prevent deactivating the current user
        if ($user->id === auth()->id()) {
            return redirect()->route('admin.users.index')
                            ->with('error', 'You cannot deactivate your own account.');
        }

        $user->update(['is_active' => !$user->is_active]);

        $status = $user->is_active ? 'activated' : 'deactivated';
        return redirect()->route('admin.users.index')
                        ->with('success', "User {$status} successfully.");
    }

    /**
     * Show role management interface.
     */
    public function roles()
    {
        // Check if user has permission to assign roles
        if (!auth()->user()->hasPermission('assign_roles')) {
            abort(403, 'You do not have permission to manage roles.');
        }
         
        $roles = Role::with('permissions')->get();
        $permissions = \App\Models\Permission::active()->get()->groupBy('category');
        
        return view('admin.users.roles', compact('roles', 'permissions'));
    }

    /**
     * Update role permissions.
     */
    public function updateRolePermissions(Request $request, Role $role)
    {
        // Check if user has permission to assign roles
        if (!auth()->user()->hasPermission('assign_roles')) {
            abort(403, 'You do not have permission to manage roles.');
        }

        $request->validate([
            'permissions' => 'array',
            'permissions.*' => 'exists:permissions,id',
        ]);

        $role->permissions()->sync($request->permissions ?? []);

        return redirect()->route('admin.roles.index')
                        ->with('success', 'Role permissions updated successfully.');
    }
}
