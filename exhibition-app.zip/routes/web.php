<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\FormBuilderController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\PaymentController;
// use App\Http\Controllers\PaystackController; // removed legacy controller
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Public event routes (no authentication required)
Route::get('/event/{event}', [EventController::class, 'publicShow'])->name('events.public.show');
Route::get('/event/{event}/floorplan', [BookingController::class, 'publicFloorplan'])->name('events.public.floorplan');
Route::get('/event/{event}/floorplan/{accessToken}', [BookingController::class, 'publicFloorplanWithToken'])->name('events.public.floorplan-token');

// Public booking routes (no authentication required)
Route::get('/event/{eventSlug}/book/{itemId}', [BookingController::class, 'showOwnerForm'])->name('bookings.owner-form');
Route::get('/event/{eventSlug}/booking/{accessToken}/owner', [BookingController::class, 'showOwnerFormWithToken'])->name('bookings.owner-form-token');
Route::post('/event/{eventSlug}/book/{itemId}', [BookingController::class, 'processOwnerForm'])->name('bookings.process-owner');
Route::post('/event/{eventSlug}/booking/{accessToken}/owner', [BookingController::class, 'processOwnerFormWithToken'])->name('bookings.process-owner-token');
Route::post('/event/{eventSlug}/booking/{accessToken}/remove', [BookingController::class, 'removeBooking'])->name('bookings.remove');
Route::get('/event/{eventSlug}/booking/{accessToken}/change-space/{itemId}', [BookingController::class, 'changeSpace'])->name('bookings.change-space');
Route::get('/event/{eventSlug}/booking/{accessToken}/members', [BookingController::class, 'showMemberForm'])->name('bookings.member-form');
Route::post('/event/{eventSlug}/booking/{accessToken}/members', [BookingController::class, 'processMemberForm'])->name('bookings.process-members');
Route::post('/event/{eventSlug}/booking/{accessToken}/save-members', [BookingController::class, 'saveMembers'])->name('bookings.save-members');
Route::post('/event/{eventSlug}/booking/{accessToken}/member/{memberId}/delete', [BookingController::class, 'deleteMember'])->name('bookings.delete-member');
Route::post('/admin/bookings/{booking}/delete', [BookingController::class, 'destroy'])->name('admin.bookings.destroy')->middleware(['auth']);

// Debug route to check user roles
Route::get('/debug/user-roles', function () {
    if (!auth()->check()) {
        return response()->json(['error' => 'Not authenticated']);
    }
    
    $user = auth()->user()->load('roles');
    
    // Get permissions using the fixed method
    $permissions = $user->permissions()->get();
    
    // Also check what roles exist in the database
    $allRoles = \App\Models\Role::all()->pluck('name')->toArray();
    
    return response()->json([
        'user_id' => $user->id,
        'user_email' => $user->email,
        'roles' => $user->roles->pluck('name')->toArray(),
        'roles_count' => $user->roles->count(),
        'is_admin' => $user->isAdmin(),
        'permissions' => $permissions->pluck('name')->toArray(),
        'permissions_count' => $permissions->count(),
        'all_roles_in_db' => $allRoles,
        'admin_role_exists' => in_array('admin', $allRoles)
    ]);
})->middleware(['auth']);

// Simple test route to verify routes are working
Route::get('/test-route', function () {
    return response()->json([
        'message' => 'Route is working!',
        'timestamp' => now(),
        'server' => 'production'
    ]);
});

// Test event delete route
Route::post('/test-event-delete/{id}', function ($id) {
    return response()->json([
        'message' => 'Event delete route working!',
        'event_id' => $id,
        'timestamp' => now()
    ]);
});


// Simple test route for event delete
Route::post('/test-events-delete/{id}', function ($id) {
    return response()->json([
        'message' => 'Event delete test route working!',
        'event_id' => $id,
        'url' => request()->url(),
        'method' => request()->method(),
        'timestamp' => now()
    ]);
});

// Temporary delete route without middleware for testing
Route::post('/test-delete/{booking}', function ($bookingId) {
    return response()->json([
        'message' => 'POST Delete route hit!',
        'booking_id' => $bookingId,
        'timestamp' => now()
    ]);
});

// GET route for testing (easier to test in browser)
Route::get('/test-delete/{booking}', function ($bookingId) {
    return response()->json([
        'message' => 'GET Delete route hit!',
        'booking_id' => $bookingId,
        'timestamp' => now(),
        'method' => 'GET'
    ]);
});
Route::post('/event/{eventSlug}/booking/{accessToken}/member/{memberId}/update', [BookingController::class, 'updateMember'])->name('bookings.update-member');
Route::get('/event/{eventSlug}/booking/{accessToken}/payment', [BookingController::class, 'showPayment'])->name('bookings.payment');
Route::post('/event/{eventSlug}/booking/{accessToken}/payment', [PaymentController::class, 'processPayment'])->name('bookings.process-payment');
Route::get('/event/{eventSlug}/booking/{accessToken}/paystack/callback', [PaymentController::class, 'paystackCallback'])->name('payments.paystack.callback');
Route::get('/event/{eventSlug}/booking/{accessToken}/paystack/status', [PaystackController::class, 'showPaymentStatus'])->name('paystack.status');
Route::get('/event/{eventSlug}/booking/{accessToken}/pesapal/callback', [PaymentController::class, 'pesapalCallback'])->name('payments.pesapal.callback');
Route::get('/event/{eventSlug}/booking/{accessToken}/pesapal/cancel', [PaymentController::class, 'pesapalCancel'])->name('payments.pesapal.cancel');
Route::post('/event/{eventSlug}/pesapal/ipn', [PaymentController::class, 'pesapalIPN'])->name('payments.pesapal.ipn');
Route::get('/event/{eventSlug}/booking/{accessToken}/success', [BookingController::class, 'showSuccess'])->name('bookings.success');

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// Admin routes
Route::middleware(['auth', 'verified'])->prefix('admin')->name('admin.')->group(function () {
    Route::resource('payment-methods', \App\Http\Controllers\Admin\PaymentMethodController::class)->middleware('permission:manage_payment_methods');
    Route::patch('payment-methods/{paymentMethod}/toggle-status', [\App\Http\Controllers\Admin\PaymentMethodController::class, 'toggleStatus'])->name('payment-methods.toggle-status')->middleware('permission:manage_payment_methods');
    Route::patch('payment-methods/{paymentMethod}/set-default', [\App\Http\Controllers\Admin\PaymentMethodController::class, 'setDefault'])->name('payment-methods.set-default')->middleware('permission:manage_payment_methods');
    
    // Role Management routes (Admin only) - Must come before users resource routes
    Route::get('roles', [\App\Http\Controllers\UserManagementController::class, 'roles'])->name('roles.index')->middleware('permission:assign_roles');
    Route::patch('roles/{role}/permissions', [\App\Http\Controllers\UserManagementController::class, 'updateRolePermissions'])->name('roles.permissions')->middleware('permission:assign_roles');
    
    // User Management routes (Admin only)
    Route::resource('users', \App\Http\Controllers\UserManagementController::class)->middleware('permission:manage_users');
    Route::patch('users/{user}/toggle-status', [\App\Http\Controllers\UserManagementController::class, 'toggleStatus'])->name('users.toggle-status')->middleware('permission:manage_users');
    
    // Test route to check if admin routes work
    Route::get('test-admin', function () {
        return response()->json([
            'message' => 'Admin route is working!',
            'user' => auth()->user() ? auth()->user()->email : 'Not logged in',
            'roles' => auth()->user() ? auth()->user()->roles->pluck('name')->toArray() : [],
            'is_admin' => auth()->user() ? auth()->user()->hasRole('admin') : false
        ]);
    })->middleware('permission:manage_users')->name('test.admin');
    
    // Event Email Settings routes (Admin only)
    Route::get('events/{event}/email-settings', [\App\Http\Controllers\Admin\EventEmailSettingsController::class, 'show'])->name('events.email-settings')->middleware('permission:manage_email_settings');
    Route::post('events/{event}/email-settings', [\App\Http\Controllers\Admin\EventEmailSettingsController::class, 'store'])->name('events.email-settings.store')->middleware('permission:manage_email_settings');
    Route::post('events/{event}/email-settings/test', [\App\Http\Controllers\Admin\EventEmailSettingsController::class, 'test'])->name('events.email-settings.test')->middleware('permission:manage_email_settings');
    Route::delete('events/{event}/email-settings', [\App\Http\Controllers\Admin\EventEmailSettingsController::class, 'destroy'])->name('events.email-settings.destroy')->middleware('permission:manage_email_settings');
});

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::post('/profile/delete', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // Event routes
    Route::resource('events', EventController::class);
    Route::post('/events/{event:slug}/delete', [EventController::class, 'destroy'])->name('events.delete');
    Route::post('/events/{event}/transfer-ownership', [EventController::class, 'transferOwnership'])->name('events.transfer-ownership')->middleware('role:admin');
    Route::get('/events-dashboard', [EventController::class, 'dashboard'])->name('events.overview');
    
    // Event-specific routes
    Route::get('/events/{event}/dashboard', [EventController::class, 'eventDashboard'])->name('events.dashboard');
    Route::get('/events/{event}/floorplan', [EventController::class, 'floorplan'])->name('events.floorplan')->middleware('permission:manage_floorplans,manage_own_floorplans');
    Route::post('/events/{event}/floorplan/save', [EventController::class, 'saveFloorplan'])->name('events.floorplan.save')->middleware('permission:manage_floorplans,manage_own_floorplans');
    Route::get('/events/{event}/floorplan/load', [EventController::class, 'loadFloorplan'])->name('events.floorplan.load')->middleware('permission:manage_floorplans,manage_own_floorplans');
    Route::get('/events/{event}/registration', [EventController::class, 'registration'])->name('events.registration');
    
    // Floorplan maintenance routes
    Route::get('/events/{event}/floorplan/check-orphaned-bookings', [EventController::class, 'checkOrphanedBookings'])->name('events.floorplan.check-orphaned')->middleware('permission:manage_floorplans,manage_own_floorplans');
    Route::post('/events/{event}/floorplan/cleanup-orphaned-bookings', [EventController::class, 'cleanupOrphanedBookings'])->name('events.floorplan.cleanup-orphaned')->middleware('permission:manage_floorplans,manage_own_floorplans');
    
    // Form Builder routes
    Route::resource('events.form-builders', FormBuilderController::class)->middleware('permission:manage_forms,manage_own_forms');
    Route::get('/events/{event}/form-builders/{formBuilder}/design', [FormBuilderController::class, 'design'])->name('events.form-builders.design')->middleware('permission:manage_forms,manage_own_forms');
    Route::get('/events/{event}/form-builders/{formBuilder}/preview', [FormBuilderController::class, 'preview'])->name('events.form-builders.preview')->middleware('permission:manage_forms,manage_own_forms');
    Route::get('/events/{event}/form-builders/{formBuilder}/json', [FormBuilderController::class, 'getFormJson'])->name('events.form-builders.json')->middleware('permission:manage_forms,manage_own_forms');
    
    // Email Template routes
    Route::resource('events.email-templates', \App\Http\Controllers\Admin\EmailTemplateController::class)->middleware('permission:manage_emails,manage_own_emails');
    Route::post('/events/{event}/email-templates/{emailTemplate}/clone', [\App\Http\Controllers\Admin\EmailTemplateController::class, 'clone'])->name('events.email-templates.clone')->middleware('permission:manage_emails,manage_own_emails');
    Route::post('/events/{event}/email-templates/{emailTemplate}/test', [\App\Http\Controllers\Admin\EmailTemplateController::class, 'test'])->name('events.email-templates.test')->middleware('permission:manage_emails,manage_own_emails');
    Route::patch('/events/{event}/email-templates/{emailTemplate}/toggle-status', [\App\Http\Controllers\Admin\EmailTemplateController::class, 'toggleStatus'])->name('events.email-templates.toggle-status')->middleware('permission:manage_emails,manage_own_emails');
    
    // Reports routes
    Route::get('/events/{event}/reports/bookings', [EventController::class, 'bookingsReport'])->name('events.reports.bookings')->middleware('permission:view_booking_reports');
    Route::get('/events/{event}/reports/bookings/pdf', [EventController::class, 'bookingsReportPdf'])->name('events.reports.bookings.pdf')->middleware('permission:view_booking_reports');
    Route::get('/events/{event}/reports/booth-owner/{boothOwner}', [EventController::class, 'boothOwnerDetails'])->name('events.reports.booth-owner-details')->middleware('permission:view_booking_reports');
    
    // Booth Member routes (for admin access) - using web routes instead of API routes
    Route::put('/booth-members', [EventController::class, 'storeBoothMember'])->name('booth-members.store');
    Route::get('/booth-members/{member}/edit', [EventController::class, 'getBoothMemberForEdit'])->name('booth-members.edit');
    Route::get('/booth-members/new/{boothOwner}', [EventController::class, 'getFormFieldsForNewMember'])->name('booth-members.new');
    Route::put('/booth-members/{member}', [EventController::class, 'updateBoothMember'])->name('booth-members.update');
    Route::post('/booth-members/{member}/delete', [EventController::class, 'deleteBoothMember'])->name('booth-members.delete');

});

// Removed legacy PaystackController routes; callbacks handled by PaymentController

// Receipt generation route
Route::get('/event/{eventSlug}/booking/{accessToken}/receipt', [PaymentController::class, 'generateReceipt'])->name('bookings.receipt');

// Resend payment email route
Route::post('/event/{eventSlug}/booking/{accessToken}/resend-payment-email', [BookingController::class, 'resendPaymentEmail'])->name('bookings.resend-payment-email');

// Resend member registration email route
Route::post('/event/{eventSlug}/booking/{accessToken}/resend-member-email', [BookingController::class, 'resendMemberEmail'])->name('bookings.resend-member-email');

// Artisan Commands for cPanel (Web-based execution)
Route::prefix('artisan')->group(function () {
    // Clear caches
    Route::get('/clear-cache', function () {
        try {
            \Artisan::call('cache:clear');
            \Artisan::call('config:clear');
            \Artisan::call('view:clear');
            \Artisan::call('route:clear');
            return response()->json([
                'success' => true,
                'message' => 'All caches cleared successfully!',
                'commands' => ['cache:clear', 'config:clear', 'view:clear', 'route:clear']
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error clearing caches: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.clear-cache');

    // Run migrations
    Route::get('/migrate', function () {
        try {
            \Artisan::call('migrate', ['--force' => true]);
            return response()->json([
                'success' => true,
                'message' => 'Migrations completed successfully!',
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error running migrations: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.migrate');

    // Run migrations with status
    Route::get('/migrate-status', function () {
        try {
            \Artisan::call('migrate:status');
            return response()->json([
                'success' => true,
                'message' => 'Migration status retrieved successfully!',
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error getting migration status: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.migrate-status');

    // Optimize application
    Route::get('/optimize', function () {
        try {
            \Artisan::call('optimize');
            \Artisan::call('config:cache');
            \Artisan::call('route:cache');
            \Artisan::call('view:cache');
            return response()->json([
                'success' => true,
                'message' => 'Application optimized successfully!',
                'commands' => ['optimize', 'config:cache', 'route:cache', 'view:cache']
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error optimizing application: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.optimize');

    // Clear and optimize
    Route::get('/clear-and-optimize', function () {
        try {
            // Clear everything first
            \Artisan::call('cache:clear');
            \Artisan::call('config:clear');
            \Artisan::call('view:clear');
            \Artisan::call('route:clear');
            
            // Then optimize
            \Artisan::call('optimize');
            \Artisan::call('config:cache');
            \Artisan::call('route:cache');
            \Artisan::call('view:cache');
            
            return response()->json([
                'success' => true,
                'message' => 'Application cleared and optimized successfully!',
                'commands' => [
                    'Cleared: cache, config, view, route',
                    'Optimized: application, config, route, view'
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error clearing and optimizing: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.clear-and-optimize');

    // Queue work (process pending jobs)
    Route::get('/queue-work', function () {
        try {
            \Artisan::call('queue:work', ['--once' => true]);
            return response()->json([
                'success' => true,
                'message' => 'Queue processed successfully!',
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error processing queue: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.queue-work');

    // Check application status
    Route::get('/status', function () {
        try {
            $status = [
                'app_name' => config('app.name'),
                'app_env' => config('app.env'),
                'app_debug' => config('app.debug'),
                'database_connection' => \DB::connection()->getPdo() ? 'Connected' : 'Failed',
                'cache_driver' => config('cache.default'),
                'queue_driver' => config('queue.default'),
                'storage_link' => file_exists(public_path('storage')) ? 'Linked' : 'Not Linked',
                'php_version' => PHP_VERSION,
                'laravel_version' => app()->version(),
                'memory_usage' => memory_get_usage(true),
                'peak_memory' => memory_get_peak_usage(true)
            ];
            
            return response()->json([
                'success' => true,
                'message' => 'Application status retrieved successfully!',
                'status' => $status
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error getting status: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.status');

    // Create storage link
    Route::get('/storage-link', function () {
        try {
            \Artisan::call('storage:link');
            return response()->json([
                'success' => true,
                'message' => 'Storage link created successfully!',
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error creating storage link: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.storage-link');

    // List all available commands
    Route::get('/list', function () {
        try {
            \Artisan::call('list');
            return response()->json([
                'success' => true,
                'message' => 'Available commands listed successfully!',
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error listing commands: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.list');

    // Build Vite assets for production
    Route::get('/build', function () {
        try {
            // Check if npm is available
            $npmPath = shell_exec('which npm 2>&1');
            if (empty($npmPath)) {
                return response()->json([
                    'success' => false,
                    'message' => 'NPM is not available on this server. Please build assets locally and upload them.',
                    'instructions' => [
                        '1. Run "npm run build" locally',
                        '2. Upload the "public/build" folder to your server',
                        '3. Ensure the build folder is in your public_html/public/ directory'
                    ]
                ], 500);
            }

            // Check if package.json exists
            if (!file_exists(base_path('package.json'))) {
                return response()->json([
                    'success' => false,
                    'message' => 'package.json not found. Please ensure you have the correct project structure.'
                ], 500);
            }

            // Install dependencies if node_modules doesn't exist
            if (!is_dir(base_path('node_modules'))) {
                \Artisan::call('shell_exec', ['command' => 'npm install']);
            }

            // Build assets
            $buildCommand = 'npm run build';
            $output = shell_exec($buildCommand . ' 2>&1');
            
            if (file_exists(public_path('build/manifest.json'))) {
                return response()->json([
                    'success' => true,
                    'message' => 'Vite assets built successfully!',
                    'output' => $output,
                    'manifest_exists' => true,
                    'build_path' => public_path('build')
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Build completed but manifest.json not found. Check the output for errors.',
                    'output' => $output,
                    'manifest_exists' => false
                ], 500);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error building assets: ' . $e->getMessage(),
                'instructions' => [
                    '1. Run "npm run build" locally',
                    '2. Upload the "public/build" folder to your server',
                    '3. Ensure the build folder is in your public_html/public/ directory'
                ]
            ], 500);
        }
    })->name('artisan.build');

    // Check Vite build status
    Route::get('/build-status', function () {
        try {
            $manifestPath = public_path('build/manifest.json');
            $buildDir = public_path('build');
            
            $status = [
                'manifest_exists' => file_exists($manifestPath),
                'build_dir_exists' => is_dir($buildDir),
                'manifest_path' => $manifestPath,
                'build_dir_path' => $buildDir,
                'build_dir_contents' => is_dir($buildDir) ? scandir($buildDir) : [],
                'public_path' => public_path(),
                'base_path' => base_path()
            ];
            
            if (file_exists($manifestPath)) {
                $manifest = json_decode(file_get_contents($manifestPath), true);
                $status['manifest_content'] = $manifest;
            }
            
            return response()->json([
                'success' => true,
                'message' => 'Build status checked successfully!',
                'status' => $status
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error checking build status: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.build-status');

    // Seeder routes for production updates
    Route::get('/seed-permissions', function () {
        try {
            \Artisan::call('db:seed', ['--class' => 'PermissionSeeder', '--force' => true]);
            return response()->json([
                'success' => true,
                'message' => 'Permissions seeded successfully!',
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error seeding permissions: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.seed-permissions');

    Route::get('/seed-roles', function () {
        try {
            \Artisan::call('db:seed', ['--class' => 'RoleSeeder', '--force' => true]);
            return response()->json([
                'success' => true,
                'message' => 'Roles seeded successfully!',
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error seeding roles: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.seed-roles');

    Route::get('/seed-assign-admin-role', function () {
        try {
            \Artisan::call('db:seed', ['--class' => 'AssignAdminRoleSeeder', '--force' => true]);
            return response()->json([
                'success' => true,
                'message' => 'Admin role assigned successfully!',
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error assigning admin role: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.seed-assign-admin-role');

    Route::get('/seed-user-management', function () {
        try {
            // Run all user management seeders in order
            \Artisan::call('db:seed', ['--class' => 'PermissionSeeder', '--force' => true]);
            \Artisan::call('db:seed', ['--class' => 'RoleSeeder', '--force' => true]);
            \Artisan::call('db:seed', ['--class' => 'AssignAdminRoleSeeder', '--force' => true]);
            
            return response()->json([
                'success' => true,
                'message' => 'User management system seeded successfully!',
                'commands' => ['PermissionSeeder', 'RoleSeeder', 'AssignAdminRoleSeeder'],
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error seeding user management system: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.seed-user-management');

    Route::get('/seed-all', function () {
        try {
            // Run all seeders
            \Artisan::call('db:seed', ['--force' => true]);
            return response()->json([
                'success' => true,
                'message' => 'All seeders completed successfully!',
                'output' => \Artisan::output()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error running all seeders: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.seed-all');

    // Check seeder status
    Route::get('/seeder-status', function () {
        try {
            $status = [
                'permissions' => \App\Models\Permission::count(),
                'roles' => \App\Models\Role::count(),
                'users_with_roles' => \App\Models\User::whereHas('roles')->count(),
                'admin_users' => \App\Models\User::whereHas('roles', function($query) {
                    $query->where('name', 'admin');
                })->count(),
                'database_connection' => \DB::connection()->getPdo() ? 'Connected' : 'Disconnected',
                'timestamp' => now()->toDateTimeString()
            ];

            return response()->json([
                'success' => true,
                'message' => 'Seeder status retrieved successfully!',
                'status' => $status
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error getting seeder status: ' . $e->getMessage()
            ], 500);
        }
    })->name('artisan.seeder-status');
});


require __DIR__.'/auth.php';
 